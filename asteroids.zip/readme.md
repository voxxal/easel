# Welcome to your new Easel project!

You have just created a new Easel project.

To get started:
1. Give your game a name in `easel.toml`.
2. Go to `main.easel` to start building your game!

To learn more about Easel, go to https://easel.games.
