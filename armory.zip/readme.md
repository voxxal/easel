# Welcome to your new Easel project!

You have just created a new Easel project.

To get started:
1. Give your game a name in `easel.toml`.
2. Go to `main.easel` to start building your game!

# About Easel

Easel is a programming language with a built-in multiplayer game engine.
Make shareable little games and learn to code, the fun way!
To learn more about Easel, go to https://easel.games.
